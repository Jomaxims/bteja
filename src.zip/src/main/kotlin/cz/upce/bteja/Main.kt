package cz.upce.bteja

import org.antlr.v4.runtime.CharStreams
import org.antlr.v4.runtime.CommonTokenStream
import org.antlr.v4.runtime.tree.ParseTreeWalker
import java.io.File

fun main(args: Array<String>) {
//    val text = File("./example.txt").readText()
    val text = prog
    val lexer = OberonLexer(CharStreams.fromString(text))
    val tokenStream = CommonTokenStream(lexer).apply { fill() }
    val parser = OberonParser(tokenStream)
//    ParseTreeWalker.DEFAULT.walk(TreeListener(parser), parser.module())
    TreeVisitor().visit(parser.module())

//    tokenStream.tokens.forEach { println("${lexer.vocabulary.getDisplayName(it.type)}: ${it.text}") }
}

val prog = """
    MODULE e3;

    CONST
        factorial = 10 *(20);
        
    VAR
        pepa, arnost: INTEGER;
        str: STRING;

    PROCEDURE recFact(f: ARRAY OF ARRAY OF ARRAY OF INTEGER; p: pepa): INTEGER;
    BEGIN
        IF f <= 1 THEN
            RETURN 1;
        ELSE
            RETURN f * recFact(f - 1);
        END;
    END recFact;

    BEGIN
        PRINT_STR("Factorial: ");
        PRINT_INT(recFact(factorial));
    END e3.
""".trimIndent()