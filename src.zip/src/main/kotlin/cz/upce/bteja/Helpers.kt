package cz.upce.bteja

import org.antlr.v4.runtime.atn.SemanticContext.Empty
import org.antlr.v4.runtime.tree.TerminalNode

data class Value(var value: Any) {
    val type get() = value::class

    companion object {
        val Empty = Value(Any())
    }
}

fun TerminalNode.toIntValue() = Value(this.text.toInt())
fun TerminalNode.toRealValue() = Value(this.text.toDouble())
fun TerminalNode.toStringValue() = Value(this.text)

data class Variable(var value: Value?, val isConstant: Boolean = false) {
    companion object {
        val Empty = Variable(Value.Empty)
    }
}

fun <T:Any> T.toValue() = Value(this)

class ProgramContext {
    val procedures = mutableMapOf<String, String>()
}

class ExecutionContext(
    val programContext: ProgramContext,
    val parentContext: ExecutionContext?
) {
    val variables = mutableMapOf<String, Variable>()
    val hasParent get() = parentContext != null

    fun hasVariable(name: String): Boolean =
        if (variables.keys.contains(name))
            true
        else if (!hasParent)
            false
        else parentContext!!.hasVariable(name)
}