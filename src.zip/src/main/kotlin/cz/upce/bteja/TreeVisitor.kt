package cz.upce.bteja

import java.util.*

class TreeVisitor : OberonBaseVisitor<Value>() {
    private val programContext = ProgramContext()
    private val contexts = Stack<ExecutionContext>().apply {
        push(ExecutionContext(programContext, null))
    }

    init {
        addDefaultVarsAndProcedures()
    }

    private fun addDefaultVarsAndProcedures() {
        contexts.peek().apply {
            variables["INTEGER"] = Variable.Empty
            variables["REAL"] = Variable.Empty
            variables["STRING"] = Variable.Empty
        }

        programContext.apply {
            procedures["PRINT_STR"] = ""
            procedures["PRINT_INT"] = ""
        }
    }

    override fun visitModule(ctx: OberonParser.ModuleContext?): Value {
        return visitChildren(ctx)
    }

    override fun visitConstDeclaration(ctx: OberonParser.ConstDeclarationContext): Value {
        val constName = ctx.ident().text

        val value = visit(ctx.simpleExpression())

        contexts.peek().variables[constName] = Variable(value, true)

        return Value.Empty
    }

    override fun visitSimpleExpression(ctx: OberonParser.SimpleExpressionContext): Value {
        return visitChildren(ctx)
    }

    override fun visitFactor(ctx: OberonParser.FactorContext): Value {
        ctx.INTEGER()?.let {
            return it.toIntValue()
        }
        ctx.REAL()?.let {
            return it.toRealValue()
        }
        ctx.STRING()?.let {
            return it.toStringValue()
        }
        ctx.expression()?.let {
            return visit(it)
        }
        ctx.designator()?.let {
            return visit(it)
        }
        ctx.ident()?.let {
            return visit(it)
        }
        ctx.procedureCall()?.let {
            return visit(it)
        }

        return visitChildren(ctx)
    }
}